﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Challenge_2
{
    internal class Member
    {
        public string name;
        public int memberId;
        public string[] booksBought;
        public int numBooksBought;
        public double moneyInBank;
        public double amountSpent;

        // Default Constructor
        public Member()
        {
            name = "Unknown";
            memberId = 0;
            booksBought = new string[100]; // Assuming max 100 books for simplicity
            numBooksBought = 0;
            moneyInBank = 0.0;
            amountSpent = 0.0;
        }

        // Parameterized Constructor
        public Member(string name, int memberId, double initialBankBalance)
        {
            this.name = name;
            this.memberId = memberId;
            this.booksBought = new string[100];
            this.numBooksBought = 0;
            this.moneyInBank = initialBankBalance;
            this.amountSpent = 0.0;
        }

        // Name Operations
        public void SetName(string newName)
        {
            name = newName;
        }

        public void ModifyName(string newName)
        {
            SetName(newName); // Essentially does the same as SetName
        }

        public void ShowName()
        {
            Console.WriteLine($"Name: {name}");
        }

        // Books Bought Operations (Number of books)
        public void SetNumBooksBought(int num)
        {
            numBooksBought = num;
        }

        public void ModifyNumBooksBought(int num)
        {
            numBooksBought = num;
        }

        public void UpdateNumBooksBought(int additionalBooks)
        {
            numBooksBought += additionalBooks;
        }

        public void ShowNumBooksBought()
        {
            Console.WriteLine($"Number of Books Bought: {numBooksBought}");
        }

        // Books Bought Operations (List of books)
        public void AddBookToBoughtList(string bookName, double bookPrice)
        {
            if (numBooksBought < booksBought.Length)
            {
                if (moneyInBank >= bookPrice)
                {
                    booksBought[numBooksBought] = bookName;
                    numBooksBought++;
                    UpdateAmountSpent(bookPrice);
                    moneyInBank -= bookPrice;
                    Console.WriteLine($"Successfully purchased '{bookName}' for ${bookPrice}.");
                }
                else
                {
                    Console.WriteLine($"Not enough money in bank to buy '{bookName}'.");
                }
            }
            else
            {
                Console.WriteLine("Cannot buy more books, list is full.");
            }
        }

        public void ShowBooksBoughtList()
        {
            Console.Write("Books Bought: ");
            if (numBooksBought == 0)
            {
                Console.WriteLine("None");
                return;
            }
            for (int i = 0; i < numBooksBought; i++)
            {
                Console.Write(booksBought[i] + (i == numBooksBought - 1 ? "" : ", "));
            }
            Console.WriteLine();
        }

        // Amount Spent Operations
        public void SetAmountSpent(double amount)
        {
            amountSpent = amount;
        }

        public void ModifyAmountSpent(double amount)
        {
            amountSpent = amount;
        }

        public void UpdateAmountSpent(double additionalAmount)
        {
            amountSpent += additionalAmount;
        }

        public void ShowAmountSpent()
        {
            Console.WriteLine($"Amount Spent: ${amountSpent}");
        }

        // Money In Bank Operations
        public void SetMoneyInBank(double amount)
        {
            moneyInBank = amount;
        }

        public void AddMoneyToBank(double amount)
        {
            moneyInBank += amount;
        }

        public void ShowMoneyInBank()
        {
            Console.WriteLine($"Money In Bank: ${moneyInBank}");
        }

        public void ShowFullDetails()
        {
            Console.WriteLine("\n--- Member Details ---");
            Console.WriteLine($"Member ID: {memberId}");
            ShowName();
            ShowMoneyInBank();
            ShowAmountSpent();
            ShowNumBooksBought();
            ShowBooksBoughtList();
            Console.WriteLine("----------------------\n");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Testing operations using a single object for the driver program
            Member member = new Member("John Doe", 101, 500.00);
            int choice = 0;

            while (choice != 9)
            {
                Console.WriteLine("=== Member Management Menu ===");
                Console.WriteLine("1. Show Full Member Details");
                Console.WriteLine("2. Update Member Name");
                Console.WriteLine("3. Show Member Name");
                Console.WriteLine("4. Buy a Book");
                Console.WriteLine("5. Show Books Bought Info");
                Console.WriteLine("6. Add Money to Bank");
                Console.WriteLine("7. Show Money in Bank");
                Console.WriteLine("8. Show Amount Spent");
                Console.WriteLine("9. Exit");
                Console.Write("Enter your choice: ");

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    choice = 0;
                }

                if (choice == 1)
                {
                    member.ShowFullDetails();
                }
                else if (choice == 2)
                {
                    Console.Write("Enter new name: ");
                    string newName = Console.ReadLine();
                    member.ModifyName(newName);
                    Console.WriteLine("Name updated.");
                }
                else if (choice == 3)
                {
                    member.ShowName();
                }
                else if (choice == 4)
                {
                    Console.Write("Enter book name: ");
                    string bookName = Console.ReadLine();
                    Console.Write("Enter book price: ");
                    if (double.TryParse(Console.ReadLine(), out double price) && price >= 0)
                    {
                        member.AddBookToBoughtList(bookName, price);
                    }
                    else
                    {
                        Console.WriteLine("Invalid price. Please enter a valid positive number.");
                    }
                }
                else if (choice == 5)
                {
                    member.ShowNumBooksBought();
                    member.ShowBooksBoughtList();
                }
                else if (choice == 6)
                {
                    Console.Write("Enter amount to add to bank: ");
                    if (double.TryParse(Console.ReadLine(), out double amount) && amount >= 0)
                    {
                        member.AddMoneyToBank(amount);
                        Console.WriteLine("Money added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Invalid amount. Please enter a valid positive number.");
                    }
                }
                else if (choice == 7)
                {
                    member.ShowMoneyInBank();
                }
                else if (choice == 8)
                {
                    member.ShowAmountSpent();
                }
                else if (choice == 9)
                {
                    Console.WriteLine("Exiting program...");
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                }

                Console.WriteLine();
            }
        }
    }

}

