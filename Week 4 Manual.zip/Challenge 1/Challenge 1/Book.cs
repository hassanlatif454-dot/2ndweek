﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Challenge_1
{
    internal class Book
    {
        public string title;
        public string[] authors;
        public int numAuthors;
        public string publisher;
        public string isbn;
        public double price;
        public int stock;
        public int yearOfPublication;

        // Constructors
        public Book()
        {
            title = "";
            authors = new string[4];
            numAuthors = 0;
            publisher = "";
            isbn = "";
            price = 0.0;
            stock = 0;
            yearOfPublication = 0;
        }

        public Book(string title, string publisher, string isbn, double price, int stock, int yearOfPublication)
        {
            this.title = title;
            this.authors = new string[4];
            this.numAuthors = 0;
            this.publisher = publisher;
            this.isbn = isbn;
            this.price = price;
            this.stock = stock;
            this.yearOfPublication = yearOfPublication;
        }

        // Title Operations
        public void SetTitle(string t) { title = t; }
        public string GetTitle() { return title; }
        public void ShowTitle() { Console.WriteLine("Title: " + title); }
        public bool CheckTitle(string t) { return string.Equals(title, t, StringComparison.OrdinalIgnoreCase); }

        // Author Operations
        public void AddAuthor(string author)
        {
            if (numAuthors < 4)
            {
                authors[numAuthors] = author;
                numAuthors++;
            }
            else
            {
                Console.WriteLine("Cannot add more than 4 authors.");
            }
        }
        public void ShowAuthors()
        {
            Console.Write("Authors: ");
            if (numAuthors == 0)
            {
                Console.WriteLine("None");
                return;
            }
            for (int i = 0; i < numAuthors; i++)
            {
                Console.Write(authors[i] + (i == numAuthors - 1 ? "" : ", "));
            }
            Console.WriteLine();
        }
        public int GetNumAuthors() { return numAuthors; }
        public bool CheckAuthor(string author)
        {
            for (int i = 0; i < numAuthors; i++)
            {
                if (string.Equals(authors[i], author, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        // Publisher Operations
        public void SetPublisher(string p) { publisher = p; }
        public string GetPublisher() { return publisher; }
        public void ShowPublisher() { Console.WriteLine("Publisher: " + publisher); }
        public bool CheckPublisher(string p) { return string.Equals(publisher, p, StringComparison.OrdinalIgnoreCase); }

        // ISBN Operations
        public void SetIsbn(string i) { isbn = i; }
        public string GetIsbn() { return isbn; }
        public void ShowIsbn() { Console.WriteLine("ISBN: " + isbn); }
        public bool CheckIsbn(string i) { return string.Equals(isbn, i, StringComparison.OrdinalIgnoreCase); }

        // Price Operations
        public void SetPrice(double p) { price = p; }
        public double GetPrice() { return price; }
        public void ShowPrice() { Console.WriteLine("Price: $" + price); }

        // Stock Operations
        public void SetStock(int s) { stock = s; }
        public int GetStock() { return stock; }
        public void ShowStock() { Console.WriteLine("Copies in Stock: " + stock); }
        public void UpdateStock(int amount)
        {
            stock += amount;
            if (stock < 0) stock = 0;
        }

        // Year Operations
        public void SetYearOfPublication(int y) { yearOfPublication = y; }
        public int GetYearOfPublication() { return yearOfPublication; }
        public void ShowYearOfPublication() { Console.WriteLine("Year of Publication: " + yearOfPublication); }

        // Show All Book Details
        public void ShowBookDetails()
        {
            Console.WriteLine("-------------------------------------------------");
            ShowTitle();
            ShowAuthors();
            ShowPublisher();
            ShowIsbn();
            ShowPrice();
            ShowStock();
            ShowYearOfPublication();
            Console.WriteLine("-------------------------------------------------");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Book[] books = new Book[100];
            int bookCount = 0;
            int choice = 0;

            while (choice != 6)
            {
                Console.WriteLine("\n=== Book Management System ===");
                Console.WriteLine("1. Add a Book");
                Console.WriteLine("2. Search Book by Title");
                Console.WriteLine("3. Search Book by ISBN");
                Console.WriteLine("4. Update Copies in Stock");
                Console.WriteLine("5. Display All Books");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");

                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    choice = 0;
                }

                if (choice == 1)
                {
                    if (bookCount < 100)
                    {
                        Console.Write("Enter Title: ");
                        string title = Console.ReadLine();
                        Console.Write("Enter Publisher: ");
                        string publisher = Console.ReadLine();
                        Console.Write("Enter ISBN: ");
                        string isbn = Console.ReadLine();

                        Console.Write("Enter Price: ");
                        double price;
                        double.TryParse(Console.ReadLine(), out price);

                        Console.Write("Enter Number of Copies in Stock: ");
                        int stock;
                        int.TryParse(Console.ReadLine(), out stock);

                        Console.Write("Enter Year of Publication: ");
                        int year;
                        int.TryParse(Console.ReadLine(), out year);

                        Book newBook = new Book(title, publisher, isbn, price, stock, year);

                        Console.Write("Enter number of authors (up to 4): ");
                        int numAuthors;
                        int.TryParse(Console.ReadLine(), out numAuthors);
                        if (numAuthors > 4) numAuthors = 4;
                        if (numAuthors < 0) numAuthors = 0;

                        for (int i = 0; i < numAuthors; i++)
                        {
                            Console.Write($"Enter Author {i + 1} Name: ");
                            newBook.AddAuthor(Console.ReadLine());
                        }

                        books[bookCount] = newBook;
                        bookCount++;
                        Console.WriteLine("Book added successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Storage is full. Cannot add more books.");
                    }
                }
                else if (choice == 2)
                {
                    Console.Write("Enter Title to search: ");
                    string searchTitle = Console.ReadLine();
                    bool foundByTitle = false;
                    for (int i = 0; i < bookCount; i++)
                    {
                        if (books[i].CheckTitle(searchTitle))
                        {
                            books[i].ShowBookDetails();
                            foundByTitle = true;
                            break; // optional: break if we only expect one
                        }
                    }
                    if (!foundByTitle)
                        Console.WriteLine("Book not found.");
                }
                else if (choice == 3)
                {
                    Console.Write("Enter ISBN to search: ");
                    string searchIsbn = Console.ReadLine();
                    bool foundByIsbn = false;
                    for (int i = 0; i < bookCount; i++)
                    {
                        if (books[i].CheckIsbn(searchIsbn))
                        {
                            books[i].ShowBookDetails();
                            foundByIsbn = true;
                            break; // optional: break if we only expect one
                        }
                    }
                    if (!foundByIsbn)
                        Console.WriteLine("Book not found.");
                }
                else if (choice == 4)
                {
                    Console.Write("Enter Title of the book to update stock: ");
                    string updateTitle = Console.ReadLine();
                    bool foundForUpdate = false;
                    for (int i = 0; i < bookCount; i++)
                    {
                        if (books[i].CheckTitle(updateTitle))
                        {
                            Console.WriteLine($"Current Stock: {books[i].GetStock()}");
                            Console.Write("Enter amount to add/remove (use negative for removal): ");
                            if (int.TryParse(Console.ReadLine(), out int amount))
                            {
                                books[i].UpdateStock(amount);
                                Console.WriteLine($"Stock updated successfully. New Stock: {books[i].GetStock()}");
                            }
                            else
                            {
                                Console.WriteLine("Invalid amount.");
                            }
                            foundForUpdate = true;
                            break;
                        }
                    }
                    if (!foundForUpdate)
                        Console.WriteLine("Book not found.");
                }
                else if (choice == 5)
                {
                    if (bookCount == 0)
                    {
                        Console.WriteLine("No books available.");
                    }
                    else
                    {
                        for (int i = 0; i < bookCount; i++)
                        {
                            books[i].ShowBookDetails();
                        }
                    }
                }
                else if (choice == 6)
                {
                    Console.WriteLine("Exiting program...");
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please try again.");
                }
            }
        }
    }

}

