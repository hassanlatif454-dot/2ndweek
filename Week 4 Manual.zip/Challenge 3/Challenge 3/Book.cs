﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Challenge_3
{
    internal class Book
    {
        public string Title { get; set; }
        public string Authors { get; set; }
        public string Publisher { get; set; }
        public string ISBN { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }
        public int YearOfPublication { get; set; }

        public Book(string title, string authors, string publisher, string isbn, double price, int stock, int year)
        {
            Title = title;
            Authors = authors;
            Publisher = publisher;
            ISBN = isbn;
            Price = price;
            Stock = stock;
            YearOfPublication = year;
        }

        public void DisplayBook()
        {
            Console.WriteLine($"Title: {Title}");
            Console.WriteLine($"Authors: {Authors}");
            Console.WriteLine($"Publisher: {Publisher}");
            Console.WriteLine($"ISBN: {ISBN}");
            Console.WriteLine($"Price: ${Price:F2}");
            Console.WriteLine($"Stock: {Stock}");
            Console.WriteLine($"Year: {YearOfPublication}");
            Console.WriteLine("-----------------------");
        }
    }

    class Member
    {
        public string Name { get; set; }
        public int MemberID { get; set; }
        public int BooksPurchasedCount { get; set; }
        public double TotalAmountSpent { get; set; }

        public Member(string name, int memberId)
        {
            Name = name;
            MemberID = memberId;
            BooksPurchasedCount = 0;
            TotalAmountSpent = 0;
        }

        public void DisplayMember()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Member ID: {MemberID}");
            Console.WriteLine($"Books Purchased: {BooksPurchasedCount}");
            Console.WriteLine($"Total Spent in current cycle: ${TotalAmountSpent:F2}");
            Console.WriteLine("-----------------------");
        }
    }

    class Program
    {
        static Book[] inventory = new Book[100];
        static int bookCount = 0;

        static Member[] members = new Member[100];
        static int memberCount = 0;

        static double totalSales = 0.0;
        static double totalMembershipFees = 0.0;

        static void Main(string[] args)
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== Bookstore Management System ===");
                Console.WriteLine("a. Add a Book");
                Console.WriteLine("b. Search for a Book by Title");
                Console.WriteLine("c. Search for a Book by ISBN");
                Console.WriteLine("d. Update Stock of a Book");
                Console.WriteLine("e. Add a Member");
                Console.WriteLine("f. Search for a Member by Name or ID");
                Console.WriteLine("g. Update Member Information");
                Console.WriteLine("h. Purchase a Book");
                Console.WriteLine("i. Display Total Sales and Membership Stats");
                Console.WriteLine("j. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine()?.ToLower();

                switch (choice)
                {
                    case "a": AddBook(); break;
                    case "b": SearchBookByTitle(); break;
                    case "c": SearchBookByIsbn(); break;
                    case "d": UpdateStock(); break;
                    case "e": AddMember(); break;
                    case "f": SearchMember(); break;
                    case "g": UpdateMember(); break;
                    case "h": PurchaseBook(); break;
                    case "i": DisplayStats(); break;
                    case "j":
                        exit = true;
                        Console.WriteLine("Exiting program...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }

        static void AddBook()
        {
            if (bookCount >= 100)
            {
                Console.WriteLine("Inventory is full.");
                return;
            }

            Console.Write("Enter Title: ");
            string title = Console.ReadLine();
            Console.Write("Enter Author(s): ");
            string authors = Console.ReadLine();
            Console.Write("Enter Publisher: ");
            string publisher = Console.ReadLine();
            Console.Write("Enter ISBN: ");
            string isbn = Console.ReadLine();

            Console.Write("Enter Price: ");
            if (!double.TryParse(Console.ReadLine(), out double price)) price = 0;

            Console.Write("Enter Stock: ");
            if (!int.TryParse(Console.ReadLine(), out int stock)) stock = 0;

            Console.Write("Enter Year of Publication: ");
            if (!int.TryParse(Console.ReadLine(), out int year)) year = 0;

            inventory[bookCount++] = new Book(title, authors, publisher, isbn, price, stock, year);
            Console.WriteLine("Book added successfully.");
        }

        static void SearchBookByTitle()
        {
            Console.Write("Enter Title to search: ");
            string title = Console.ReadLine();
            bool found = false;
            for (int i = 0; i < bookCount; i++)
            {
                if (inventory[i].Title.Equals(title, StringComparison.OrdinalIgnoreCase))
                {
                    inventory[i].DisplayBook();
                    found = true;
                }
            }
            if (!found) Console.WriteLine("Book not found.");
        }

        static void SearchBookByIsbn()
        {
            Console.Write("Enter ISBN to search: ");
            string isbn = Console.ReadLine();
            bool found = false;
            for (int i = 0; i < bookCount; i++)
            {
                if (inventory[i].ISBN.Equals(isbn, StringComparison.OrdinalIgnoreCase))
                {
                    inventory[i].DisplayBook();
                    found = true;
                }
            }
            if (!found) Console.WriteLine("Book not found.");
        }

        static void UpdateStock()
        {
            Console.Write("Enter Title or ISBN of the book to update: ");
            string query = Console.ReadLine();

            for (int i = 0; i < bookCount; i++)
            {
                if (inventory[i].Title.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                    inventory[i].ISBN.Equals(query, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Current Stock for '{inventory[i].Title}': {inventory[i].Stock}");
                    Console.Write("Enter amount to add (positive) or remove (negative): ");
                    if (int.TryParse(Console.ReadLine(), out int change))
                    {
                        if (inventory[i].Stock + change < 0)
                        {
                            Console.WriteLine("Cannot remove more items than are in stock.");
                        }
                        else
                        {
                            inventory[i].Stock += change;
                            Console.WriteLine("Stock updated successfully.");
                        }
                    }
                    return;
                }
            }
            Console.WriteLine("Book not found.");
        }

        static void AddMember()
        {
            if (memberCount >= 100)
            {
                Console.WriteLine("Member list is full.");
                return;
            }

            Console.Write("Enter Member Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter Member ID (non-zero): ");
            if (!int.TryParse(Console.ReadLine(), out int id) || id == 0)
            {
                Console.WriteLine("Invalid ID. It must be a non-zero integer.");
                return;
            }

            // Check if ID already exists
            for (int i = 0; i < memberCount; i++)
            {
                if (members[i].MemberID == id)
                {
                    Console.WriteLine("Member ID already exists!");
                    return;
                }
            }

            members[memberCount++] = new Member(name, id);
            totalMembershipFees += 10.0; // $10 yearly fee
            Console.WriteLine($"Member added successfully. $10 membership fee collected.");
        }

        static void SearchMember()
        {
            Console.Write("Enter Member Name or ID to search: ");
            string query = Console.ReadLine();
            bool found = false;

            for (int i = 0; i < memberCount; i++)
            {
                if (members[i].Name.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                    members[i].MemberID.ToString() == query)
                {
                    members[i].DisplayMember();
                    found = true;
                }
            }
            if (!found) Console.WriteLine("Member not found.");
        }

        static void UpdateMember()
        {
            Console.Write("Enter Member Name or ID to update: ");
            string query = Console.ReadLine();

            for (int i = 0; i < memberCount; i++)
            {
                if (members[i].Name.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                    members[i].MemberID.ToString() == query)
                {
                    Console.WriteLine("1. Modify Name");
                    Console.WriteLine("2. Modify ID");
                    Console.WriteLine("3. Modify Both");
                    Console.Write("Enter choice: ");
                    string c = Console.ReadLine();

                    if (c == "1" || c == "3")
                    {
                        Console.Write("Enter new Name: ");
                        members[i].Name = Console.ReadLine();
                    }
                    if (c == "2" || c == "3")
                    {
                        Console.Write("Enter new ID: ");
                        if (int.TryParse(Console.ReadLine(), out int newId) && newId != 0)
                        {
                            members[i].MemberID = newId;
                        }
                        else
                        {
                            Console.WriteLine("Invalid ID entered. Skipping ID update.");
                        }
                    }
                    Console.WriteLine("Member updated successfully.");
                    return;
                }
            }
            Console.WriteLine("Member not found.");
        }

        static void PurchaseBook()
        {
            Console.Write("Are you a non-member? (yes/no): ");
            bool isNonMember = Console.ReadLine()?.ToLower() == "yes";

            Member currentMember = null;

            if (!isNonMember)
            {
                Console.Write("Enter Member ID: ");
                if (int.TryParse(Console.ReadLine(), out int id))
                {
                    for (int i = 0; i < memberCount; i++)
                    {
                        if (members[i].MemberID == id)
                        {
                            currentMember = members[i];
                            break;
                        }
                    }
                }
                if (currentMember == null)
                {
                    Console.WriteLine("Member not found. Proceeding as non-member.");
                }
            }

            Console.Write("Enter Title or ISBN of the book to purchase: ");
            string query = Console.ReadLine();
            Book bookToBuy = null;

            for (int i = 0; i < bookCount; i++)
            {
                if (inventory[i].Title.Equals(query, StringComparison.OrdinalIgnoreCase) ||
                    inventory[i].ISBN.Equals(query, StringComparison.OrdinalIgnoreCase))
                {
                    bookToBuy = inventory[i];
                    break;
                }
            }

            if (bookToBuy == null)
            {
                Console.WriteLine("Book not found.");
                return;
            }

            Console.Write($"Enter quantity of '{bookToBuy.Title}' to purchase: ");
            if (!int.TryParse(Console.ReadLine(), out int qty) || qty <= 0)
            {
                Console.WriteLine("Invalid quantity.");
                return;
            }

            if (bookToBuy.Stock < qty)
            {
                Console.WriteLine($"Not enough stock. Only {bookToBuy.Stock} available.");
                return;
            }

            double bookPrice = bookToBuy.Price;
            double subtotal = 0;

            bookToBuy.Stock -= qty; // update stock

            // Process purchase per book to apply member discounts properly
            for (int q = 0; q < qty; q++)
            {
                double currentBookPrice = bookPrice;

                if (currentMember != null)
                {
                    currentMember.BooksPurchasedCount++;

                    // 5% default discount for members
                    double discount = currentBookPrice * 0.05;
                    currentBookPrice -= discount;

                    // Check for 11th book
                    if (currentMember.BooksPurchasedCount % 11 == 0)
                    {
                        // Average of last 10 books = TotalAmountSpent / 10
                        double eleventhBookDiscount = currentMember.TotalAmountSpent / 10.0;

                        Console.WriteLine($"\n[11th Book Bonus!] You received an additional discount of ${eleventhBookDiscount:F2}!");

                        currentBookPrice -= eleventhBookDiscount;
                        if (currentBookPrice < 0) currentBookPrice = 0; // Price can't be negative

                        // Reset total spent cycle
                        currentMember.TotalAmountSpent = 0;
                    }
                    else
                    {
                        // Track spending for the 10-book cycle.
                        currentMember.TotalAmountSpent += currentBookPrice;
                    }
                }

                subtotal += currentBookPrice;
            }

            totalSales += subtotal;

            Console.WriteLine($"Purchase successful!");
            if (currentMember != null)
            {
                Console.WriteLine($"Member: {currentMember.Name}");
            }
            Console.WriteLine($"Total Cost: ${subtotal:F2}");
        }

        static void DisplayStats()
        {
            Console.WriteLine("\n=== Bookstore Statistics ===");
            Console.WriteLine($"Total Sales from Books: ${totalSales:F2}");
            Console.WriteLine($"Total Members: {memberCount}");
            Console.WriteLine($"Total Membership Fees Collected: ${totalMembershipFees:F2}");
            Console.WriteLine("-----------------------------");
        }
    }

}

